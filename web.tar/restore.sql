--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.work_in DROP CONSTRAINT work_in_ssn_fkey;
ALTER TABLE ONLY public.work_in DROP CONSTRAINT work_in_pid_fkey;
ALTER TABLE ONLY public.work_dept DROP CONSTRAINT work_dept_ssn_fkey;
ALTER TABLE ONLY public.work_dept DROP CONSTRAINT work_dept_dno_fkey;
ALTER TABLE ONLY public.undergraduate DROP CONSTRAINT undergraduate_email_fkey;
ALTER TABLE ONLY public.undergraduate DROP CONSTRAINT undergraduate_advsid_fkey;
ALTER TABLE ONLY public.undergraduate DROP CONSTRAINT undergraduate_address_fkey;
ALTER TABLE ONLY public.supervises DROP CONSTRAINT supervises_ssn_fkey;
ALTER TABLE ONLY public.supervises DROP CONSTRAINT supervises_sid_ug_fkey;
ALTER TABLE ONLY public.supervises DROP CONSTRAINT supervises_pid_fkey;
ALTER TABLE ONLY public.room DROP CONSTRAINT room_bid_fkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_ssn_fkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_dno_fkey;
ALTER TABLE ONLY public.professor DROP CONSTRAINT professor_email_fkey;
ALTER TABLE ONLY public.professor DROP CONSTRAINT professor_dno_fkey;
ALTER TABLE ONLY public.professor DROP CONSTRAINT professor_address_fkey;
ALTER TABLE ONLY public.point4 DROP CONSTRAINT point4_bid_fkey;
ALTER TABLE ONLY public.point3 DROP CONSTRAINT point3_bid_fkey;
ALTER TABLE ONLY public.point2 DROP CONSTRAINT point2_bid_fkey;
ALTER TABLE ONLY public.point1 DROP CONSTRAINT point1_bid_fkey;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_sid_fkey;
ALTER TABLE ONLY public.message DROP CONSTRAINT message_sender_fkey;
ALTER TABLE ONLY public.message DROP CONSTRAINT message_email_fkey;
ALTER TABLE ONLY public.enrolled_in DROP CONSTRAINT enrolled_in_sid_fkey;
ALTER TABLE ONLY public.enrolled_in DROP CONSTRAINT enrolled_in_cid_fkey;
ALTER TABLE ONLY public.dept DROP CONSTRAINT dept_ssn_fkey;
ALTER TABLE ONLY public.course DROP CONSTRAINT course_ssn_fkey;
ALTER TABLE ONLY public.course DROP CONSTRAINT course_dno_fkey;
DROP TRIGGER reserve_seat ON public.enrolled_in;
ALTER TABLE ONLY public.work_in DROP CONSTRAINT work_in_pkey;
ALTER TABLE ONLY public.work_dept DROP CONSTRAINT work_dept_pkey;
ALTER TABLE ONLY public.undergraduate DROP CONSTRAINT undergraduate_pkey;
ALTER TABLE ONLY public.supervises DROP CONSTRAINT supervises_pkey;
ALTER TABLE ONLY public.s_address DROP CONSTRAINT s_address_pkey;
ALTER TABLE ONLY public.room DROP CONSTRAINT room_pkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
ALTER TABLE ONLY public.professor DROP CONSTRAINT professor_pkey;
ALTER TABLE ONLY public.professor DROP CONSTRAINT professor_email_key;
ALTER TABLE ONLY public.point4 DROP CONSTRAINT point4_pkey;
ALTER TABLE ONLY public.point3 DROP CONSTRAINT point3_pkey;
ALTER TABLE ONLY public.point2 DROP CONSTRAINT point2_pkey;
ALTER TABLE ONLY public.point1 DROP CONSTRAINT point1_pkey;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_pkey;
ALTER TABLE ONLY public.message DROP CONSTRAINT message_pkey;
ALTER TABLE ONLY public.f_address DROP CONSTRAINT f_address_pkey;
ALTER TABLE ONLY public.enrolled_in DROP CONSTRAINT enrolled_in_pkey;
ALTER TABLE ONLY public.undergraduate DROP CONSTRAINT email_ukey;
ALTER TABLE ONLY public.email DROP CONSTRAINT email_pkey;
ALTER TABLE ONLY public.dept DROP CONSTRAINT dept_pkey;
ALTER TABLE ONLY public.course DROP CONSTRAINT course_pkey;
ALTER TABLE ONLY public.building DROP CONSTRAINT building_pkey;
DROP TABLE public.work_in;
DROP TABLE public.work_dept;
DROP TABLE public.undergraduate;
DROP TABLE public.supervises;
DROP SEQUENCE public.sid;
DROP TABLE public.s_address;
DROP TABLE public.room;
DROP SEQUENCE public.rid;
DROP TABLE public.project;
DROP TABLE public.professor;
DROP TABLE public.point4;
DROP TABLE public.point3;
DROP TABLE public.point2;
DROP TABLE public.point1;
DROP SEQUENCE public.pid4;
DROP SEQUENCE public.pid3;
DROP SEQUENCE public.pid2;
DROP SEQUENCE public.pid1;
DROP SEQUENCE public.pid;
DROP TABLE public.payment;
DROP SEQUENCE public.mid;
DROP TABLE public.message;
DROP TABLE public.f_address;
DROP TABLE public.enrolled_in;
DROP TABLE public.email;
DROP TABLE public.dept;
DROP SEQUENCE public.dno;
DROP TABLE public.course;
DROP TABLE public.building;
DROP SEQUENCE public.bid;
DROP FUNCTION public.process_seats();
DROP TYPE public.grade;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: grade; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE grade AS ENUM (
    'F',
    'D',
    'C',
    'B',
    'A'
);


ALTER TYPE grade OWNER TO postgres;

--
-- Name: process_seats(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION process_seats() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF (TG_OP = 'DELETE') THEN UPDATE Course C SET remaining_seats = remaining_seats + 1 WHERE C.cid = OLD.cid; RETURN OLD; ELSIF (TG_OP = 'INSERT') THEN UPDATE Course C SET remaining_seats = remaining_seats - 1 WHERE C.cid = NEW.cid; RETURN NEW; END IF; END; $$;


ALTER FUNCTION public.process_seats() OWNER TO postgres;

--
-- Name: bid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE bid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bid OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: building; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE building (
    bid integer DEFAULT nextval('bid'::regclass) NOT NULL,
    name character varying(30)
);


ALTER TABLE building OWNER TO postgres;

--
-- Name: course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE course (
    cid integer NOT NULL,
    ssn character(11),
    dno integer NOT NULL,
    room character varying(20),
    capacity integer,
    remaining_seats integer,
    name character varying(70),
    semester character(2)
);


ALTER TABLE course OWNER TO postgres;

--
-- Name: dno; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE dno
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dno OWNER TO postgres;

--
-- Name: dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE dept (
    dno integer DEFAULT nextval('dno'::regclass) NOT NULL,
    dname character varying(30),
    ssn character(11) NOT NULL,
    office character varying(30)
);


ALTER TABLE dept OWNER TO postgres;

--
-- Name: email; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE email (
    email character varying(40) NOT NULL
);


ALTER TABLE email OWNER TO postgres;

--
-- Name: enrolled_in; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE enrolled_in (
    sid integer NOT NULL,
    cid integer NOT NULL,
    date character(4) NOT NULL,
    grade grade,
    paid boolean DEFAULT false
);


ALTER TABLE enrolled_in OWNER TO postgres;

--
-- Name: f_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE f_address (
    phone character(12),
    zip character(5),
    street character varying(40) NOT NULL,
    city character varying(20),
    state character(2)
);


ALTER TABLE f_address OWNER TO postgres;

--
-- Name: message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE message (
    message text DEFAULT ''::text NOT NULL,
    read boolean DEFAULT false,
    email character varying(40) NOT NULL,
    subject character varying(50) DEFAULT ''::character varying,
    sender character varying(40) NOT NULL
);


ALTER TABLE message OWNER TO postgres;

--
-- Name: mid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mid OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE payment (
    sid integer NOT NULL,
    cardnum character varying(19) NOT NULL,
    exp_date date
);


ALTER TABLE payment OWNER TO postgres;

--
-- Name: pid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pid OWNER TO postgres;

--
-- Name: pid1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pid1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pid1 OWNER TO postgres;

--
-- Name: pid2; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pid2
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pid2 OWNER TO postgres;

--
-- Name: pid3; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pid3
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pid3 OWNER TO postgres;

--
-- Name: pid4; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pid4
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pid4 OWNER TO postgres;

--
-- Name: point1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE point1 (
    pid1 integer DEFAULT nextval('pid1'::regclass) NOT NULL,
    x1 integer,
    y1 integer,
    rid integer NOT NULL,
    bid integer NOT NULL
);


ALTER TABLE point1 OWNER TO postgres;

--
-- Name: point2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE point2 (
    pid2 integer DEFAULT nextval('pid2'::regclass) NOT NULL,
    x2 integer,
    y2 integer,
    rid integer NOT NULL,
    bid integer NOT NULL
);


ALTER TABLE point2 OWNER TO postgres;

--
-- Name: point3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE point3 (
    pid3 integer DEFAULT nextval('pid3'::regclass) NOT NULL,
    x3 integer,
    y3 integer,
    rid integer NOT NULL,
    bid integer NOT NULL
);


ALTER TABLE point3 OWNER TO postgres;

--
-- Name: point4; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE point4 (
    pid4 integer DEFAULT nextval('pid4'::regclass) NOT NULL,
    x4 integer,
    y4 integer,
    rid integer NOT NULL,
    bid integer NOT NULL
);


ALTER TABLE point4 OWNER TO postgres;

--
-- Name: professor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE professor (
    ssn character(11) NOT NULL,
    age integer,
    rank integer,
    speciality character varying(40),
    name character varying(40),
    email character varying(40) NOT NULL,
    address character varying(40),
    password character varying(20),
    office character varying(30),
    dno integer NOT NULL
);


ALTER TABLE professor OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE project (
    pid integer DEFAULT nextval('pid'::regclass) NOT NULL,
    manager_ssn character(11) NOT NULL,
    sponsor character varying(60),
    start_date date,
    end_date date,
    budget real,
    dno integer NOT NULL,
    description text DEFAULT ''::text
);


ALTER TABLE project OWNER TO postgres;

--
-- Name: rid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE rid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rid OWNER TO postgres;

--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE room (
    bid integer NOT NULL,
    rid integer NOT NULL
);


ALTER TABLE room OWNER TO postgres;

--
-- Name: s_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE s_address (
    phone character(12),
    zip character(5),
    street character varying(40) NOT NULL,
    city character varying(20),
    state character(2)
);


ALTER TABLE s_address OWNER TO postgres;

--
-- Name: sid; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sid OWNER TO postgres;

--
-- Name: supervises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE supervises (
    pid integer NOT NULL,
    ssn character(11) NOT NULL,
    sid_ug integer NOT NULL
);


ALTER TABLE supervises OWNER TO postgres;

--
-- Name: undergraduate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE undergraduate (
    sid integer DEFAULT nextval('sid'::regclass) NOT NULL,
    age integer,
    deg_prog character varying(40),
    name character varying(50),
    advsid integer NOT NULL,
    password character varying(20),
    level character varying(9),
    email character varying(40) NOT NULL,
    address character varying(40) NOT NULL
);


ALTER TABLE undergraduate OWNER TO postgres;

--
-- Name: work_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE work_dept (
    pc_time integer,
    ssn character(11) NOT NULL,
    dno integer NOT NULL
);


ALTER TABLE work_dept OWNER TO postgres;

--
-- Name: work_in; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE work_in (
    pid integer NOT NULL,
    ssn character(11) NOT NULL
);


ALTER TABLE work_in OWNER TO postgres;

--
-- Name: bid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('bid', 2, true);


--
-- Data for Name: building; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY building (bid, name) FROM stdin;
\.
COPY building (bid, name) FROM '$$PATH$$/2322.dat';

--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY course (cid, ssn, dno, room, capacity, remaining_seats, name, semester) FROM stdin;
\.
COPY course (cid, ssn, dno, room, capacity, remaining_seats, name, semester) FROM '$$PATH$$/2314.dat';

--
-- Data for Name: dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dept (dno, dname, ssn, office) FROM stdin;
\.
COPY dept (dno, dname, ssn, office) FROM '$$PATH$$/2306.dat';

--
-- Name: dno; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('dno', 4, true);


--
-- Data for Name: email; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY email (email) FROM stdin;
\.
COPY email (email) FROM '$$PATH$$/2319.dat';

--
-- Data for Name: enrolled_in; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY enrolled_in (sid, cid, date, grade, paid) FROM stdin;
\.
COPY enrolled_in (sid, cid, date, grade, paid) FROM '$$PATH$$/2315.dat';

--
-- Data for Name: f_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY f_address (phone, zip, street, city, state) FROM stdin;
\.
COPY f_address (phone, zip, street, city, state) FROM '$$PATH$$/2318.dat';

--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY message (message, read, email, subject, sender) FROM stdin;
\.
COPY message (message, read, email, subject, sender) FROM '$$PATH$$/2333.dat';

--
-- Name: mid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mid', 1, false);


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY payment (sid, cardnum, exp_date) FROM stdin;
\.
COPY payment (sid, cardnum, exp_date) FROM '$$PATH$$/2334.dat';

--
-- Name: pid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pid', 12, true);


--
-- Name: pid1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pid1', 1, false);


--
-- Name: pid2; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pid2', 1, false);


--
-- Name: pid3; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pid3', 1, false);


--
-- Name: pid4; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pid4', 1, false);


--
-- Data for Name: point1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY point1 (pid1, x1, y1, rid, bid) FROM stdin;
\.
COPY point1 (pid1, x1, y1, rid, bid) FROM '$$PATH$$/2328.dat';

--
-- Data for Name: point2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY point2 (pid2, x2, y2, rid, bid) FROM stdin;
\.
COPY point2 (pid2, x2, y2, rid, bid) FROM '$$PATH$$/2329.dat';

--
-- Data for Name: point3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY point3 (pid3, x3, y3, rid, bid) FROM stdin;
\.
COPY point3 (pid3, x3, y3, rid, bid) FROM '$$PATH$$/2330.dat';

--
-- Data for Name: point4; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY point4 (pid4, x4, y4, rid, bid) FROM stdin;
\.
COPY point4 (pid4, x4, y4, rid, bid) FROM '$$PATH$$/2331.dat';

--
-- Data for Name: professor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY professor (ssn, age, rank, speciality, name, email, address, password, office, dno) FROM stdin;
\.
COPY professor (ssn, age, rank, speciality, name, email, address, password, office, dno) FROM '$$PATH$$/2305.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY project (pid, manager_ssn, sponsor, start_date, end_date, budget, dno, description) FROM stdin;
\.
COPY project (pid, manager_ssn, sponsor, start_date, end_date, budget, dno, description) FROM '$$PATH$$/2309.dat';

--
-- Name: rid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('rid', 1, false);


--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY room (bid, rid) FROM stdin;
\.
COPY room (bid, rid) FROM '$$PATH$$/2323.dat';

--
-- Data for Name: s_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY s_address (phone, zip, street, city, state) FROM stdin;
\.
COPY s_address (phone, zip, street, city, state) FROM '$$PATH$$/2317.dat';

--
-- Name: sid; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sid', 35, true);


--
-- Data for Name: supervises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY supervises (pid, ssn, sid_ug) FROM stdin;
\.
COPY supervises (pid, ssn, sid_ug) FROM '$$PATH$$/2312.dat';

--
-- Data for Name: undergraduate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY undergraduate (sid, age, deg_prog, name, advsid, password, level, email, address) FROM stdin;
\.
COPY undergraduate (sid, age, deg_prog, name, advsid, password, level, email, address) FROM '$$PATH$$/2311.dat';

--
-- Data for Name: work_dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY work_dept (pc_time, ssn, dno) FROM stdin;
\.
COPY work_dept (pc_time, ssn, dno) FROM '$$PATH$$/2307.dat';

--
-- Data for Name: work_in; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY work_in (pid, ssn) FROM stdin;
\.
COPY work_in (pid, ssn) FROM '$$PATH$$/2313.dat';

--
-- Name: building building_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY building
    ADD CONSTRAINT building_pkey PRIMARY KEY (bid);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY course
    ADD CONSTRAINT course_pkey PRIMARY KEY (cid);


--
-- Name: dept dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dept
    ADD CONSTRAINT dept_pkey PRIMARY KEY (dno);


--
-- Name: email email_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY email
    ADD CONSTRAINT email_pkey PRIMARY KEY (email);


--
-- Name: undergraduate email_ukey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY undergraduate
    ADD CONSTRAINT email_ukey UNIQUE (email);


--
-- Name: enrolled_in enrolled_in_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY enrolled_in
    ADD CONSTRAINT enrolled_in_pkey PRIMARY KEY (sid, cid, date);


--
-- Name: f_address f_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY f_address
    ADD CONSTRAINT f_address_pkey PRIMARY KEY (street);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY message
    ADD CONSTRAINT message_pkey PRIMARY KEY (email, message, sender);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (sid, cardnum);


--
-- Name: point1 point1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point1
    ADD CONSTRAINT point1_pkey PRIMARY KEY (pid1, bid, rid);


--
-- Name: point2 point2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point2
    ADD CONSTRAINT point2_pkey PRIMARY KEY (pid2, bid, rid);


--
-- Name: point3 point3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point3
    ADD CONSTRAINT point3_pkey PRIMARY KEY (pid3, bid, rid);


--
-- Name: point4 point4_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point4
    ADD CONSTRAINT point4_pkey PRIMARY KEY (pid4, bid, rid);


--
-- Name: professor professor_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY professor
    ADD CONSTRAINT professor_email_key UNIQUE (email);


--
-- Name: professor professor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY professor
    ADD CONSTRAINT professor_pkey PRIMARY KEY (ssn);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_pkey PRIMARY KEY (pid);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY room
    ADD CONSTRAINT room_pkey PRIMARY KEY (bid, rid);


--
-- Name: s_address s_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY s_address
    ADD CONSTRAINT s_address_pkey PRIMARY KEY (street);


--
-- Name: supervises supervises_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY supervises
    ADD CONSTRAINT supervises_pkey PRIMARY KEY (sid_ug, pid);


--
-- Name: undergraduate undergraduate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY undergraduate
    ADD CONSTRAINT undergraduate_pkey PRIMARY KEY (sid);


--
-- Name: work_dept work_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY work_dept
    ADD CONSTRAINT work_dept_pkey PRIMARY KEY (ssn, dno);


--
-- Name: work_in work_in_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY work_in
    ADD CONSTRAINT work_in_pkey PRIMARY KEY (pid, ssn);


--
-- Name: enrolled_in reserve_seat; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER reserve_seat AFTER INSERT OR DELETE ON enrolled_in FOR EACH ROW EXECUTE PROCEDURE process_seats();


--
-- Name: course course_dno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY course
    ADD CONSTRAINT course_dno_fkey FOREIGN KEY (dno) REFERENCES dept(dno);


--
-- Name: course course_ssn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY course
    ADD CONSTRAINT course_ssn_fkey FOREIGN KEY (ssn) REFERENCES professor(ssn);


--
-- Name: dept dept_ssn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dept
    ADD CONSTRAINT dept_ssn_fkey FOREIGN KEY (ssn) REFERENCES professor(ssn);


--
-- Name: enrolled_in enrolled_in_cid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY enrolled_in
    ADD CONSTRAINT enrolled_in_cid_fkey FOREIGN KEY (cid) REFERENCES course(cid);


--
-- Name: enrolled_in enrolled_in_sid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY enrolled_in
    ADD CONSTRAINT enrolled_in_sid_fkey FOREIGN KEY (sid) REFERENCES undergraduate(sid);


--
-- Name: message message_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY message
    ADD CONSTRAINT message_email_fkey FOREIGN KEY (email) REFERENCES email(email) ON DELETE CASCADE;


--
-- Name: message message_sender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY message
    ADD CONSTRAINT message_sender_fkey FOREIGN KEY (sender) REFERENCES email(email);


--
-- Name: payment payment_sid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_sid_fkey FOREIGN KEY (sid) REFERENCES undergraduate(sid) ON DELETE CASCADE;


--
-- Name: point1 point1_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point1
    ADD CONSTRAINT point1_bid_fkey FOREIGN KEY (bid, rid) REFERENCES room(bid, rid) ON DELETE CASCADE;


--
-- Name: point2 point2_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point2
    ADD CONSTRAINT point2_bid_fkey FOREIGN KEY (bid, rid) REFERENCES room(bid, rid) ON DELETE CASCADE;


--
-- Name: point3 point3_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point3
    ADD CONSTRAINT point3_bid_fkey FOREIGN KEY (bid, rid) REFERENCES room(bid, rid) ON DELETE CASCADE;


--
-- Name: point4 point4_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY point4
    ADD CONSTRAINT point4_bid_fkey FOREIGN KEY (bid, rid) REFERENCES room(bid, rid) ON DELETE CASCADE;


--
-- Name: professor professor_address_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY professor
    ADD CONSTRAINT professor_address_fkey FOREIGN KEY (address) REFERENCES f_address(street);


--
-- Name: professor professor_dno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY professor
    ADD CONSTRAINT professor_dno_fkey FOREIGN KEY (dno) REFERENCES dept(dno);


--
-- Name: professor professor_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY professor
    ADD CONSTRAINT professor_email_fkey FOREIGN KEY (email) REFERENCES email(email);


--
-- Name: project project_dno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_dno_fkey FOREIGN KEY (dno) REFERENCES dept(dno);


--
-- Name: project project_ssn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_ssn_fkey FOREIGN KEY (manager_ssn) REFERENCES professor(ssn);


--
-- Name: room room_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY room
    ADD CONSTRAINT room_bid_fkey FOREIGN KEY (bid) REFERENCES building(bid) ON DELETE CASCADE;


--
-- Name: supervises supervises_pid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY supervises
    ADD CONSTRAINT supervises_pid_fkey FOREIGN KEY (pid) REFERENCES project(pid);


--
-- Name: supervises supervises_sid_ug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY supervises
    ADD CONSTRAINT supervises_sid_ug_fkey FOREIGN KEY (sid_ug) REFERENCES undergraduate(sid);


--
-- Name: supervises supervises_ssn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY supervises
    ADD CONSTRAINT supervises_ssn_fkey FOREIGN KEY (ssn) REFERENCES professor(ssn);


--
-- Name: undergraduate undergraduate_address_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY undergraduate
    ADD CONSTRAINT undergraduate_address_fkey FOREIGN KEY (address) REFERENCES s_address(street);


--
-- Name: undergraduate undergraduate_advsid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY undergraduate
    ADD CONSTRAINT undergraduate_advsid_fkey FOREIGN KEY (advsid) REFERENCES undergraduate(sid);


--
-- Name: undergraduate undergraduate_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY undergraduate
    ADD CONSTRAINT undergraduate_email_fkey FOREIGN KEY (email) REFERENCES email(email);


--
-- Name: work_dept work_dept_dno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY work_dept
    ADD CONSTRAINT work_dept_dno_fkey FOREIGN KEY (dno) REFERENCES dept(dno);


--
-- Name: work_dept work_dept_ssn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY work_dept
    ADD CONSTRAINT work_dept_ssn_fkey FOREIGN KEY (ssn) REFERENCES professor(ssn) ON DELETE CASCADE;


--
-- Name: work_in work_in_pid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY work_in
    ADD CONSTRAINT work_in_pid_fkey FOREIGN KEY (pid) REFERENCES project(pid);


--
-- Name: work_in work_in_ssn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY work_in
    ADD CONSTRAINT work_in_ssn_fkey FOREIGN KEY (ssn) REFERENCES professor(ssn);


--
-- PostgreSQL database dump complete
--

